'use strict';


/**
 * This is a Lambda function that sends an SMS text message. 
 * It subscribes to the topic created by the Dog Park Deep Lens topic
 * and extracts the dog recognition probability fields. It then formats the message
 * and includes the URL of the image which the Greengrass Lambda function created
 * on Deep Lens itself a second or two before. This text and URL are then sent
 * to the phone number entered as an environment variable below.
 */

const AWS = require('aws-sdk');

const phone_number = process.env.phone_number;
//const email = process.env.email;

const dog_park_topic = process.env.dogParkTopic;

const SNS = new AWS.SNS({ apiVersion: '2010-03-31' });


exports.handler = (event, context, callback) => {
    console.log('Received event: ', event);
    
    var prob1 = event.dog1Prob;
    var prob1Float = parseFloat(prob1);
    var dog1 = prob1Float.toFixed(0);

    var prob2 = event.dog2Prob;
    var prob2Float = parseFloat(prob2);
    var dog2 = prob2Float.toFixed(0);
    
    const dog1String = dog1 + "% :  " + event.dog1Label
    const dog2String = dog2 + "% :  " + event.dog2Label
    
    const message  =  dog1String + "\n" + dog2String + "\n" + event.URL + "\n";
    //const message  = "<!DOCTYPE html><html lang=\"en\"> <img src=\"" + event.URL + " width=100 height=100> " + "\n" + dog1String + "\n" + dog2String + "</html>";
   
    /*const params = {
        Message: message,
        PhoneNumber: phone_number
    };*/



    const params = {
        Message: message,
        TopicArn: "arn:aws:sns:us-east-1:233474427531:DogParkEmailTopic"
    };
    

    // result will go to function callback
    SNS.publish(params, callback);
};
